<?php

namespace App\Models;

use CodeIgniter\Model;

class Uvod extends Model{
    protected $table = '';
    protected $primaryKey ='';
    protected $returnType ='';
    protected $autoIncrement = 'true';
    protected $allowedFields = '';
    protected $useSoftDeletes = '';
    protected $deletedField = '';
    protected $dateFormat = '';
    protected $useTimeStamps = 'true';
    protected $createdField = '';
    protected $updatedField = '';
}