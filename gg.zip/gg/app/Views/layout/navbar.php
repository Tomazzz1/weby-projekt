<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarul" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
          <div class="collapse navbar-collapse" id="navbarul">
            <ul class="navbar-nav me-auto ">
              <li class="nav-item">
                <a class="nav-link active" style="font-family: 'Roboto Mono', sans-serif;" href="<?php echo base_url("Uvodni_Stranka")?>">Fotbal
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="font-family: 'Roboto Mono', sans-serif;" href="<?php echo base_url("seznam-tymu")?>">Seznam Týmů</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="font-family: 'Roboto Mono', sans-serif;" href="<?php echo base_url("pozice-hracu")?>">Pozice Hráčů</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" style="font-family: 'Roboto Mono', sans-serif;" href="<?php echo base_url("stadiony")?>">Stadiony + Úprava</a>
              </li>
             
             
              
            </ul>
            
          </div>
        </div>
      </nav>
     