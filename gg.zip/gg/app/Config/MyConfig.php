<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class MyConfig extends BaseConfig{
    var $perPage = 12;
    var $pagd = 8;
}